package com.capgemini.fms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;
import com.capgemini.fms.service.FmsService;
import com.capgemini.fms.service.FmsServiceImpl;

import oracle.net.aso.p;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static FmsService fmsService = new FmsServiceImpl();
	static int userId;

	public static void main(String[] args) {

		String role = login();
		if (role.equalsIgnoreCase("admin")) {
			viewAdminPage();
		} else if (role.equalsIgnoreCase("cordinator")) {
			viewCoordinatorPage();

		} else if (role.equalsIgnoreCase("participant")) {
			 viewParticpantPage();
		} else {

		}
	}

	public static String login() {
		System.out.println("Please enter your Employee ID:");
		userId = sc.nextInt();
		System.out.println("Please enter your password:");
		String password = sc.next();

		String role = fmsService.doLogin(userId, password);
		return role;
	}

	/************
	 * Coordinator Page
	 */
	private static void viewCoordinatorPage() {
		System.out.println("Coordinator Page");

		System.out.println("What do you want to do?");
		System.out.println("1. Training program Maintenance");
		System.out.println("2. Participant Enrollment");
		System.out.println("3. View Feedback Report");

		int option = sc.nextInt();
		switch (option) {
		case 1:
			System.out.println("you are in Training program Maintenance");

			System.out.println("1. Add New PROGRAM");
			System.out.println("2. Update Current PROGRAM");
			System.out.println("3. Delete PROGRAM");
			System.out.println("4. View all Current Programs");
			int key = sc.nextInt();

			switch (key) {
			case 1:
				System.out.println("Add New PROGRAM");

				Training program = new Training();
				System.out.println("Enter Training code");
				program.setTrainingCode(sc.nextInt());
				System.out.println("Enter Course code");
				program.setCourseCode(sc.next());
				System.out.println("Enter Faculty code");
				program.setFacultyCode(sc.next());
				System.out
						.println("Enter program Start date in <YYYY-MM-DD> format");
				program.setStartDate(sc.next());
				System.out.println("Enter end date in <YYYY-MM-DD> format");
				program.setEndDate(sc.next());

				int newProg = fmsService.addNewProgram(program);
				if (newProg > 0)
					System.out.println("Client layer " + newProg);

				break;

			case 2:
				System.out.println("Update Current PROGRAM Please Enter training code");
				int trainingCode = sc.nextInt();
				Training prog = new Training();
				prog=fmsService.getTrainingProgram(trainingCode);
				
				System.out.println(prog.getCourseCode());
				System.out.println(prog.getEndDate());
				
				break;

			case 3:
				System.out.println("Delete PROGRAM");

				trainingCode = sc.nextInt();

				int status = fmsService.deleteProgram(trainingCode);

				if (status > 0)
					System.out.println("Training program Deleated");

				break;
			case 4:
				System.out.println("View all Current Programs");
				ArrayList<Training> trainingArray = new ArrayList<Training>();
				trainingArray = fmsService.viewAll();
				trainingArray.forEach(i->System.out.println(i));
				break;
			default:
				break;
			}

			break;
		case 2:
			System.out.println("you are in Participant Enrollment");

			break;
		case 3:
			System.out.println("View Feedback Report");
			break;

		default:
			break;

		}

	}

	/*
	 *
	 * 
	 * 
	 * Admin
	 */
	public static void viewAdminPage() {
		Faculty faculty = new Faculty();
		System.out.println("What do you want to do?");
		System.out.println("1. Faculty Skill Maintenance");
		System.out.println("2. Course Maintenance");
		System.out.println("3. View Feedback Report");
		int choice = sc.nextInt();
		if (choice == 1) {
			System.out.println("Enter faculty ID:");
			int id = sc.nextInt();
			faculty = fmsService.getFacultyDetails(id);
			System.out.println(faculty);
			System.out.println("Enter the new skill set");
			String skills = sc.next();
			skills = skills + "," + faculty.getSkillSet();
			faculty.setSkillSet(skills);
			int success = fmsService.updateSkills(faculty);
			System.out.println(success);
		} else if (choice == 2) {
			Course course = new Course();
			System.out.println("1. Add Course");
			System.out.println("2. Delete Course");
			System.out.println("3. Modify Course");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Course ID");
				course.setCourseId(sc.nextInt());
				;
				System.out.println("Enter Course Name");
				course.setCourseName(sc.next());
				System.out.println("Enter No. of Days");
				course.setNoOfDays(sc.nextInt());
				int success = fmsService.addCourse(course);
				if (success == 1)
					System.out.println("Course Added");
				break;

			case 2:
				System.out
						.println("Enter course ID for the course to be deleted");
				int courseId = sc.nextInt();
				boolean succ = fmsService.removeCourse(courseId);
				if (succ) {
					System.out.println("Course deleted successfully.");
				} else {
					System.out.println("Course does not exist");
				}
				break;

			case 3:
				System.out
						.println("Enter course ID for the course to be modified");
				courseId = sc.nextInt();
				course = fmsService.getCourseDetails(courseId);
				if (course == null) {
					System.out.println("Course does not exist");
				} else {
					System.out.println(course);
					System.out
							.println("Enter the modified number of days for this course");
					course.setNoOfDays(sc.nextInt());
					System.out.println(course);
					succ = fmsService.updateCourse(course);
					if (succ) {
						System.out.println("Course updated successfully");
					} else {
						System.out.println("Error occured");
					}
				}
				break;

			default:
				System.out.println("Program exiting. Invalid choice");
				System.exit(0);
			}
		}
		/*
		 * else if(choice == 3){
		 * System.out.println("Which feedback report do you want to see?");
		 * System.out.println("1. All training program report");
		 * System.out.println("2. Faculty Wise training report");
		 * System.out.println("3. Feedback Defaulters report"); int option =
		 * sc.nextInt(); switch(option){ case 1:
		 * fmsService.getTrainingProgramReport(); break; case 2: break; } }
		 */
		else {
			System.out.println("Exit");
		}

	}
	
	/*
		Participant
	*/
	
	
	public static void viewParticpantPage() {
		// TODO Auto-generated method stub
		
		System.out.println("Courses assigned to you are:");
		ArrayList<Integer> enrolledCourses=fmsService.getEnrolledCourses(userId);
		System.out.println(enrolledCourses);
		System.out.println("Enter the training Code for which you want to submit feedback");
		int trainingCode=sc.nextInt();
		Feedback feedback=new Feedback();
		
		feedback.setTrainingCode(trainingCode);
		feedback.setParticipantId(userId);
		int rating=0;
		boolean validated=true;
		do
		{
			System.out.println("Rate the course on basis of Pre & Comm");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setPrsComm(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on basis of Doubt Clarification");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setClrfyDbts(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on basis of Time Management");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else 
				feedback.setTm(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on basis of handouts");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setHndOut(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on usage of HW/SW Resources");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setHwSwNtwrk(rating);
		}
		while(!validated);
		sc.nextLine();
		System.out.println("Comments regarding the Course");
		feedback.setComments(sc.nextLine());
		System.out.println("Enter any suggestion");
		feedback.setSuggestions(sc.nextLine());
		
		System.out.println("FeedBack Entered by you is :\n"+ feedback.toString());
		
		Boolean feedbackStatus=fmsService.addFeedback(feedback);
		System.out.println(feedbackStatus);
		
		
	}


	
}
