package com.capgemini.fms.dao;

import java.util.ArrayList;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;

public interface IFmsDao {

	String doLogin(int userId, String password);

	Faculty getFacultyDetails(int id);

	int updateSkills(Faculty faculty);

	int addCourse(Course course);

	boolean removeCourse(int courseId);

	Course getCourseDetails(int courseId);

	boolean updateCourse(Course course);

	int addNewProgram(Training program);

	ArrayList<Training> viewAll();

	int deleteProgram(int trainingCode);
	
	/*
	 * Participant
	*/
	ArrayList<Integer> getEnrolledCourse(int userId);

	Boolean addFeedback(Feedback feedback);

	Training getTrainingProgram(int trainingCode);

}
