package com.capgemini.fms.dao;

public interface QueryMapper {

	public static final String LOGIN_QUERY = "SELECT e.Role from EMPLOYEE_MASTER e where"
			+ " e.EMPLOYEE_ID = ? AND e.PASSWORD = ?";
	public static final String FACULTY_DETAILS_QUERY = "SELECT f.skill_set FROM FACULTY_SKILL f WHERE"
			+ " f.FACULTY_ID=?";
	public static final String UPDATE_FACULTY_SKILLS = "UPDATE FACULTY_SKILL "
			+ "SET SKILL_SET= ? WHERE FACULTY_ID=?";
	public static final String ADD_COURSE = "INSERT INTO COURSE_MASTER VALUES(?,?,?)";
	public static final String DELETE_COURSE ="DELETE FROM COURSE_MASTER WHERE COURSE_ID =?";
	public static final String VIEW_COURSE = "SELECT c.COURSE_ID, c.COURSE_NAME, c.NO_OF_DAYS FROM COURSE_MASTER c WHERE c.COURSE_ID = ?";
	public static final String UPDATE_COURSE = "UPDATE COURSE_MASTER SET NO_OF_DAYS = ? "
			+ "WHERE COURSE_ID =?";
	
	/*
		Coordinator Queries
	
	*/
	
	public static final String INSERT_PROGRAM = "Insert into TRAINING_PROGRAM values (?,?,?,?,?)";
	public static final String VIEW_ALL_PROGRAMS = "select * from Training_Program";
	public static final String DELETE_PROGRAM = " Delete from TRAINING_PROGRAM where TRAINING_CODE=?";
	public static final String GET_PROGRAM = " Select * from TRAINING_PROGRAM where TRAINING_CODE=?";
	
	
	
	/*
	 * Participant Queries
	 * 
	*/
	public static final String FETCH_ENROLLED_COURSES="Select training_code from participant_enrollment where participant_id=? AND feedback_flag=0";
	
	public static final String INSERT_FEEDBACK="insert into feedback_master values(?,?,?,?,?,?,?,?,?)";
	
	public static final String COMPLETED_FEEDBACK="Select training_code from participant_enrollment where participant_id=? AND feedback_flag=1 ";
	public static final String UPDATE_FLAG="update participant_enrollment set feedback_flag=1 where training_code=? AND participant_id=?";

}
