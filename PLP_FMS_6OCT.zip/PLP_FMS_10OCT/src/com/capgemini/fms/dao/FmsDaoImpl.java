package com.capgemini.fms.dao;

/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;*/
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;

public class FmsDaoImpl implements IFmsDao {

	PreparedStatement pstmt;
	int success = 0;
	private Faculty faculty = new Faculty();
	private Course course = new Course();
	
	 
	
	 Connection conn = DBUtil.getConnection();
	 
	 
	@Override
	public String doLogin(int userId, String password) {
		String role = null;
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(QueryMapper.LOGIN_QUERY);
			pstmt.setInt(1, userId);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				role = res.getString(1);
				System.out.println(role);
				return role;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return role;
	}

	@Override
	public Faculty getFacultyDetails(int id) {
		PreparedStatement pstmt;
		faculty = new Faculty();
		try {
			pstmt = conn.prepareStatement(QueryMapper.FACULTY_DETAILS_QUERY);
			pstmt.setInt(1, id);
			System.out.println("Inside DAO layer  "+id);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				faculty.setFacultyId(id);
				faculty.setSkillSet(res.getString(1));
				
			
				return faculty;
			}
			
			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return faculty;

	}

	@Override
	public int updateSkills(Faculty faculty) {
		PreparedStatement pstmt;
		
		int success = 0;
		try {
			pstmt = conn.prepareStatement(QueryMapper.UPDATE_FACULTY_SKILLS);
			pstmt.setString(1, faculty.getSkillSet());
			pstmt.setInt(2, faculty.getFacultyId());
			success = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return success;
	}

	@Override
	public int addCourse(Course course) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.ADD_COURSE);
			pstmt.setInt(1, course.getCourseId());
			pstmt.setString(2, course.getCourseName());
			pstmt.setInt(3, course.getNoOfDays());
			success = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return success;
	}

	@Override
	public boolean removeCourse(int courseId) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.DELETE_COURSE);
			pstmt.setInt(1, courseId);
			success = pstmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public Course getCourseDetails(int courseId) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.VIEW_COURSE);
			pstmt.setInt(1, courseId);
			
			ResultSet res = pstmt.executeQuery();
			if(res.next()){
				course.setCourseId(res.getInt(1));
				course.setCourseName(res.getString(2));
				course.setNoOfDays(res.getInt(3));
				return course;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return course;
	}

	@Override
	public boolean updateCourse(Course course) {
		try {
			pstmt = conn.prepareStatement(QueryMapper.UPDATE_COURSE);
			pstmt.setInt(1, course.getNoOfDays());
			pstmt.setInt(2, course.getCourseId());
			pstmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	
	/*
	Coordinator 
	
	*/
	@Override
	public int addNewProgram(Training program) {
		int insProg=0;
		try{
		//System.out.println("int from here");
		pstmt = conn.prepareStatement(QueryMapper.INSERT_PROGRAM);
		pstmt.setInt(1, program.getTrainingCode());
		pstmt.setString(2, program.getCourseCode());
		pstmt.setString(3, program.getFacultyCode());
		
		Date sDate=java.sql.Date.valueOf(program.getStartDate());
		Date eDate=java.sql.Date.valueOf(program.getEndDate());
		pstmt.setDate(4, sDate);
		pstmt.setDate(5, eDate);
		
		 insProg= pstmt.executeUpdate();
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		System.out.println(program.getEndDate());
		return insProg;
	}
	
	@Override
	public Training getTrainingProgram(int trainingCode) {
		
		try {
			pstmt = conn.prepareStatement(QueryMapper.GET_PROGRAM);
			pstmt.setInt(1,	trainingCode);
			ResultSet res1=pstmt.executeQuery();
			
			if(res1==null)
				return null;
			else
			{
				Training program=new Training();
				while(res1.next())
				{
					program.setTrainingCode(trainingCode);
					program.setCourseCode(res1.getString(2));
					program.setFacultyCode(res1.getString(3));
					program.setStartDate(String.valueOf(res1.getDate(4)));
					program.setEndDate(String.valueOf(res1.getDate(5)));
					
				}
				return program;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	

	@Override
	public ArrayList<Training> viewAll() {

		ArrayList<Training> trainingDao= new ArrayList<Training>();
		Training t1= new Training();
		
		try{pstmt = conn.prepareStatement(QueryMapper.VIEW_ALL_PROGRAMS);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()) {
			t1.setTrainingCode(rs.getInt(1));
			t1.setCourseCode(rs.getString(2));
			t1.setFacultyCode(rs.getString(3));
			DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
			
			String sDate=df.format(rs.getDate(4));
			t1.setStartDate(sDate);
			String endDate=df.format(rs.getDate(5));
			t1.setEndDate(endDate);
			trainingDao.add(t1);
		}}catch (Exception e) {
			e.printStackTrace();
		}
		
		return trainingDao;
	}

	@Override
	public int deleteProgram(int trainingCode) {
		int status=0;
		try {
		pstmt = conn.prepareStatement(QueryMapper.DELETE_PROGRAM);
		pstmt.setInt(1, trainingCode);
		status= pstmt.executeUpdate();
		System.out.println("inside DAO Layer"+status);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	/*
		Participant Page
	 */
	@Override
	public ArrayList<Integer> getEnrolledCourse(int userId) {
		
		ArrayList<Integer> enrolledCourses=new ArrayList<Integer>();
	
		
		try {
			pstmt=conn.prepareStatement(QueryMapper.FETCH_ENROLLED_COURSES);
			pstmt.setInt(1, userId);
			ResultSet res=pstmt.executeQuery();
			
				
			while(res.next())
			{
				enrolledCourses.add(res.getInt(1));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return enrolledCourses;
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public Boolean addFeedback(Feedback feedback) {
			int res=0;
		try {
			pstmt=conn.prepareStatement(QueryMapper.INSERT_FEEDBACK);
			pstmt.setInt(1, feedback.getTrainingCode());
			pstmt.setInt(2, feedback.getParticipantId());
			pstmt.setInt(3, feedback.getPrsComm());
			pstmt.setInt(4, feedback.getClrfyDbts());
			pstmt.setInt(5, feedback.getTm());
			pstmt.setInt(6, feedback.getHndOut());
			pstmt.setInt(7, feedback.getHwSwNtwrk());
			pstmt.setString(8, feedback.getComments());
			pstmt.setString(9, feedback.getSuggestions());
			
			res=pstmt.executeUpdate();
			if(res>0)
			{
				pstmt=conn.prepareStatement(QueryMapper.UPDATE_FLAG);
				pstmt.setInt(1, feedback.getTrainingCode());
				pstmt.setInt(2, feedback.getParticipantId());
				int res1=pstmt.executeUpdate();
				System.out.println("resss" + res1);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res>0)
			
			
			
			
			return true;
		return false;
	}

	

	
}
