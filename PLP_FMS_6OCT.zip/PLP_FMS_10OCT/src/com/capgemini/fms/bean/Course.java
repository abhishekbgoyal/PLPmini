package com.capgemini.fms.bean;

public class Course {

	private int courseId;
	private String courseName;
	private int noOfDays;
	
	
	public Course() {
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName
				+ ", noOfDays=" + noOfDays + "]";
	}
	
	public Course(int courseId, String courseName, int noOfDays) {
		this.courseId = courseId;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}
	
	
}
