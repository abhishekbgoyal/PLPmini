package com.capgemini.fms.service;

import java.util.ArrayList;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;

public interface FmsService {

	String doLogin(int userId, String password);

	Faculty getFacultyDetails(int id);

	int updateSkills(Faculty faculty);

	int addCourse(Course course);

	boolean removeCourse(int courseId);

	Course getCourseDetails(int courseId);

	boolean updateCourse(Course course);

	  int addNewProgram(Training program);

	ArrayList<Training> viewAll();

	int deleteProgram(int trainingCode);
	
	ArrayList<Integer> getEnrolledCourses(int userId);

	boolean validateRating(int rating);

	Boolean addFeedback(Feedback feedback);

}
