package com.capgemini.fms.service;

import java.util.ArrayList;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;
import com.capgemini.fms.dao.FmsDaoImpl;
import com.capgemini.fms.dao.IFmsDao;

public class FmsServiceImpl implements FmsService {

	IFmsDao fmsDao = new FmsDaoImpl();
	@Override
	public String doLogin(int userId, String password) {
		
		return fmsDao.doLogin(userId, password);
	}
	@Override
	public Faculty getFacultyDetails(int id) {
		return fmsDao.getFacultyDetails(id);
	}
	@Override
	public int updateSkills(Faculty faculty) {
		// TODO Auto-generated method stub
		return fmsDao.updateSkills(faculty);
	}
	@Override
	public int addCourse(Course course) {
		// TODO Auto-generated method stub
		return fmsDao.addCourse(course);
	}
	@Override
	public boolean removeCourse(int courseId) {
		// TODO Auto-generated method stub
		return fmsDao.removeCourse(courseId);
	}
	@Override
	public Course getCourseDetails(int courseId) {
		// TODO Auto-generated method stub
		return fmsDao.getCourseDetails(courseId);
	}
	@Override
	public boolean updateCourse(Course course) {
		// TODO Auto-generated method stub
		return fmsDao.updateCourse(course);
	}
	@Override
	public int addNewProgram(Training program) {
		// TODO Auto-generated method stub
		return fmsDao.addNewProgram(program);
	}
	@Override
	public ArrayList<Training> viewAll() {
		// TODO Auto-generated method stub
		return fmsDao.viewAll();
	}
	@Override
	public int deleteProgram(int trainingCode) {
		// TODO Auto-generated method stub
		return fmsDao.deleteProgram(trainingCode);
	}
	@Override
	public ArrayList<Integer> getEnrolledCourses(int userId) {
		// TODO Auto-generated method stub
		return fmsDao.getEnrolledCourse(userId);
	}

	@Override
	public boolean validateRating(int rating) {

		if (rating > 0 && rating < 6)
			return true;

		return false;
		// TODO Auto-generated method stub

	}

	@Override
	public Boolean addFeedback(Feedback feedback) {
		return fmsDao.addFeedback(feedback);
	}

}
