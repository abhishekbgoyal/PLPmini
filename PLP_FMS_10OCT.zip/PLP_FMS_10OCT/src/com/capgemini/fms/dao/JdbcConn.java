package com.capgemini.fms.dao;

import java.sql.*;
public class JdbcConn {

	public static void main(String[] args) {

		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XE", "system", "oracle");
			System.out.println("Connected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		
		
	}

}
